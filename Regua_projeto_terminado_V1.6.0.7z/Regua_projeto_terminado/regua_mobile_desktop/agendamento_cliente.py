from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.dropdown import DropDown
from kivy.uix.spinner import Spinner
from kivy.uix.modalview import ModalView
from kivy.uix.popup import Popup
from kivy.properties import StringProperty, BooleanProperty, ListProperty, NumericProperty, ObjectProperty
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.clock import Clock
import sqlite3
import os
import requests
from kivy.lang import Builder
from datetime import datetime, timedelta
import json

usuario = os.getlogin()
Builder.load_file('agendamento_cliente.kv')

class CustomDropDown(DropDown):
    pass

class MenuButton(Button):
    pass

class AgendamentoCard(BoxLayout):
    agendamento_id = StringProperty('')
    cliente_nome = StringProperty('')
    barbearia_nome = StringProperty('')
    data_criacao = StringProperty('')
    status = StringProperty('pendente')
    eh_meu = BooleanProperty(False)
    posicao = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super(AgendamentoCard, self).__init__(**kwargs)
        Clock.schedule_once(self.finalizar_inicializacao)
    
    def finalizar_inicializacao(self, dt):
        self.atualizar_interface()
    
    def atualizar_interface(self, *args):
        if hasattr(self, 'ids'):
            # Atualiza cores baseadas no status - CORES CORRIGIDAS
            if self.status == 'cancelado':
                self.ids.status_label.color = (0.894, 0.102, 0.110, 1)  # Vermelho
            elif self.status == 'concluido' or self.status == 'confirmado':
                self.ids.status_label.color = (0.156, 0.545, 0.270, 1)  # Verde
            elif self.status == 'andamento':
                self.ids.status_label.color = (0.047, 0.333, 0.549, 1)  # Azul
            else:  # pendente
                self.ids.status_label.color = (0.854, 0.647, 0.125, 1)  # Amarelo
            
            # Mostra/oculta botão de cancelar
            if self.eh_meu and self.status == 'pendente':
                self.ids.cancelar_btn.opacity = 1
                self.ids.cancelar_btn.disabled = False
            else:
                self.ids.cancelar_btn.opacity = 0
                self.ids.cancelar_btn.disabled = True

class CancelamentoModal(ModalView):
    message = StringProperty('')
    callback = ObjectProperty(None)
    
    def __init__(self, message, callback, **kwargs):
        super(CancelamentoModal, self).__init__(**kwargs)
        self.message = message
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False

class AgendamentoClienteScreen(Screen):
    agendamentos_data = ListProperty([])
    profile_photo = StringProperty('')
    minha_posicao = NumericProperty(0)
    is_mobile = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super(AgendamentoClienteScreen, self).__init__(**kwargs)
        self.modal = None
        self.dropdown = CustomDropDown()
        self.popup_aviso = None  # Popup para o aviso de redirecionamento
        # Verificar tamanho da tela ao inicializar
        from kivy.core.window import Window
        Window.bind(on_resize=self.on_window_resize)
        self.check_screen_size()
    
    def on_window_resize(self, window, width, height):
        """Atualiza responsividade quando a janela é redimensionada"""
        self.check_screen_size()
    
    def check_screen_size(self):
        """Verifica se está em modo mobile baseado na largura da tela"""
        from kivy.core.window import Window
        from kivy.metrics import dp
        self.is_mobile = Window.width < dp(768)
        
        # Atualizar o app global também
        app = App.get_running_app()
        if hasattr(app, 'is_mobile'):
            app.is_mobile = self.is_mobile
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_agendamentos()
        self.carregar_foto_perfil()
        self.create_dropdown()
        
        # Verifica se o usuário não tem agendamentos e mostra aviso
        if not self.agendamentos_data or self.minha_posicao == 0:
            Clock.schedule_once(lambda dt: self.mostrar_aviso_sem_agendamentos(), 0.5)
    
    def mostrar_aviso_sem_agendamentos(self):
        """Mostra aviso que o usuário não tem agendamentos e redireciona"""
        content = BoxLayout(orientation='vertical', padding=20, spacing=20)
        
        label = Label(
            text='Você não está na fila de nenhuma barbearia!\n\n'
                 'Para entrar na fila, você precisa primeiro\n'
                 'escolher uma barbearia disponível.',
            text_size=(400, None),
            halign='center',
            valign='middle',
            font_size=dp(16)
        )
        
        buttons_layout = BoxLayout(spacing=10, size_hint_y=0.3)
        
        btn_ok = Button(
            text='OK', 
            background_color=(0.133, 0.773, 0.369, 1),
            color=(1, 1, 1, 1)
        )
        btn_ok.bind(on_release=self.fechar_aviso_e_redirecionar)
        
        buttons_layout.add_widget(btn_ok)
        
        content.add_widget(label)
        content.add_widget(buttons_layout)
        
        self.popup_aviso = Popup(
            title='Nenhum Agendamento',
            content=content,
            size_hint=(0.8, 0.5),
            auto_dismiss=False
        )
        
        self.popup_aviso.open()
    
    def fechar_aviso_e_redirecionar(self, instance):
        """Fecha o popup e redireciona para barbearias"""
        if self.popup_aviso:
            self.popup_aviso.dismiss()
            self.popup_aviso = None
        self.redirecionar_para_barbearias()
    
    def redirecionar_para_barbearias(self):
        """Redireciona para a tela de barbearias"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'barbearias'
    
    def create_dropdown(self):
        """Cria o menu dropdown"""
        self.dropdown.clear_widgets()
        
        options = [
            ('Barbearias Disponíveis', self.go_to_barbearias),
            ('Meus Agendamentos', self.go_to_agendamentos),
            ('Sair', self.logout)
        ]
        
        for text, callback in options:
            btn = MenuButton(
                text=text, 
                size_hint_y=None, 
                height=dp(50),
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1]
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def open_dropdown(self, button):
        """Abre o menu dropdown"""
        self.create_dropdown()
        self.dropdown.open(button)
    
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                        foto_path = os.path.join(base_path, filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids') and 'profile_image' in self.ids:
                            self.ids.profile_image.source = foto_path
                
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
    
    def carregar_agendamentos(self):
        """Carrega os agendamentos do usuário logado"""
        app = App.get_running_app()
        if not hasattr(app, 'usuario_id') or not app.usuario_id:
            return
        
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # Busca agendamentos não confirmados do usuário
            cursor.execute("""
                SELECT a.id, a.cliente_id, a.barbearia_id, a.data_criacao, a.confirmado, a.realizado,
                    u.nome, u.sobrenome, u.foto_perfil,
                    b.nome_barbearia
                FROM regua2_agendamento a
                JOIN regua2_usuario u ON a.cliente_id = u.id
                JOIN regua2_barbearia b ON a.barbearia_id = b.id
                WHERE a.confirmado = 0
                ORDER BY a.data_criacao ASC
            """)
            
            agendamentos = cursor.fetchall()
            self.agendamentos_data = []
            
            minha_posicao = 0
            for index, agendamento in enumerate(agendamentos):
                (agendamento_id, cliente_id, barbearia_id, data_criacao, 
                confirmado, realizado, nome, sobrenome, foto_perfil, barbearia_nome) = agendamento
                
                eh_meu = (cliente_id == app.usuario_id)
                
                if eh_meu:
                    minha_posicao = index + 1
                
                # Determina status
                if realizado:
                    status = 'concluido'
                elif confirmado:
                    status = 'andamento'
                else:
                    status = 'pendente'
                
                agendamento_dict = {
                    'id': str(agendamento_id),
                    'barbearia_id': str(barbearia_id),
                    'barbearia_nome': barbearia_nome,
                    'cliente_nome': f"{nome} {sobrenome}" if eh_meu else f"Cliente {index + 1}",
                    'data_criacao': data_criacao,
                    'status': status,
                    'eh_meu': eh_meu,
                    'posicao': index + 1,
                    'foto_perfil': foto_perfil
                }
                self.agendamentos_data.append(agendamento_dict)
            
            self.minha_posicao = minha_posicao
            conn.close()
            self.atualizar_interface()
            
        except Exception as e:
            print(f"Erro ao carregar agendamentos: {e}")
    
    def atualizar_interface(self):
        """Atualiza a interface com os agendamentos carregados"""
        if hasattr(self, 'ids') and 'agendamentos_container' in self.ids:
            self.ids.agendamentos_container.clear_widgets()
            
            if not self.agendamentos_data:
                # Quando não há agendamentos, mostra apenas mensagem simples
                empty_label = Label(
                    text="Nenhum agendamento pendente encontrado",
                    size_hint_y=None,
                    height=dp(100),
                    color=(0.5, 0.5, 0.5, 1),
                    font_size=dp(16)
                )
                self.ids.agendamentos_container.add_widget(empty_label)
                return
            
            for agendamento in self.agendamentos_data:
                card = AgendamentoCard(
                    agendamento_id=agendamento['id'],
                    cliente_nome=agendamento['cliente_nome'],
                    barbearia_nome=agendamento['barbearia_nome'],
                    data_criacao=self.formatar_data(agendamento['data_criacao']),
                    status=agendamento['status'],
                    eh_meu=agendamento['eh_meu'],
                    posicao=agendamento['posicao']
                )
                card.ids.cancelar_btn.bind(
                    on_release=lambda instance, aid=agendamento['id']: self.cancelar_agendamento(aid)
                )
                self.ids.agendamentos_container.add_widget(card)
    
    def formatar_data(self, data_str):
        """Formata a data para exibição - CORRIGIDO para horário do Brasil"""
        try:
            # Remove milésimos se existirem
            if '.' in data_str:
                data_str = data_str.split('.')[0]
            
            # Parse da data
            if 'T' in data_str:
                # Formato: 2024-01-01T10:30:45
                data_obj = datetime.strptime(data_str.split('T')[0] + ' ' + data_str.split('T')[1].split('+')[0], '%Y-%m-%d %H:%M:%S')
            else:
                # Formato SQLite: 2024-01-01 10:30:45
                data_obj = datetime.strptime(data_str, '%Y-%m-%d %H:%M:%S')
            
            # CORREÇÃO: Subtrai 3 horas para ajustar do UTC para horário do Brasil
            data_obj_brasil = data_obj - timedelta(hours=3)
            
            # Formata para exibição
            return data_obj_brasil.strftime('%d/%m/%Y %H:%M')
            
        except Exception as e:
            print(f"Erro ao formatar data {data_str}: {e}")
            return data_str
    
    def cancelar_agendamento(self, agendamento_id):
        """Cancela um agendamento"""
        def confirmar_cancelamento(instance):
            if self.executar_cancelamento(agendamento_id):
                self.modal.dismiss()
                self.carregar_agendamentos()  # Recarrega a lista
            else:
                # Mostra mensagem de erro
                self.mostrar_aviso("Erro ao cancelar agendamento")
        
        self.modal = CancelamentoModal(
            message="Tem certeza que deseja cancelar este agendamento?",
            callback=confirmar_cancelamento
        )
        self.modal.open()
    
    def executar_cancelamento(self, agendamento_id):
        """Executa o cancelamento no banco de dados"""
        app = App.get_running_app()
        if not hasattr(app, 'usuario_id') or not app.usuario_id:
            return False
        
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # Verifica se o agendamento pertence ao usuário
            cursor.execute("SELECT id FROM regua2_agendamento WHERE id = ? AND cliente_id = ?", 
                         (agendamento_id, app.usuario_id))
            
            if cursor.fetchone():
                cursor.execute("DELETE FROM regua2_agendamento WHERE id = ?", (agendamento_id,))
                conn.commit()
                conn.close()
                return True
            else:
                conn.close()
                return False
                
        except Exception as e:
            print(f"Erro ao cancelar agendamento: {e}")
            return False
    
    def mostrar_aviso(self, mensagem):
        """Mostra um aviso simples"""
        modal = ModalView(size_hint=(0.8, 0.35), auto_dismiss=True)
        content = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(15))
        
        # Área do texto ocupa 70% do espaço
        label = Label(
            text=mensagem,
            text_size=(dp(350), None),
            halign='center',
            valign='middle',
            size_hint_y=0.7,
            font_size=dp(16)
        )
        content.add_widget(label)
        
        # Botão ocupa 30% do espaço
        btn_ok = Button(
            text='OK',
            size_hint_y=0.3,
            background_color=(0.133, 0.773, 0.369, 1),
            color=(1, 1, 1, 1),
            font_size=dp(16)
        )
        btn_ok.bind(on_release=modal.dismiss)
        content.add_widget(btn_ok)
        
        modal.add_widget(content)
        modal.open()
    
    def go_to_barbearias(self, instance):
        """Navega para barbearias"""
        self.dropdown.dismiss()
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'barbearias'
    
    def go_to_agendamentos(self, instance):
        """Navega para agendamentos (já está aqui)"""
        self.dropdown.dismiss()
    
    def voltar_home(self):
        """Volta para a tela home"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'home'
    
    def ir_para_perfil(self):
        """Navega para o perfil"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'perfil'
    
    def logout(self, instance):
        """Realiza logout"""
        app = App.get_running_app()
        app.usuario_id = None
        app.logado = False
        app.foto_perfil = None
        app.tipo_usuario = None
        self.dropdown.dismiss()
        self.manager.current = 'login'