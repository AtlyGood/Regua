from kivy.app import App
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.lang import Builder
from kivy.utils import get_color_from_hex
from kivy.clock import Clock
import sqlite3
import os
import django
from django.conf import settings
usuario = os.getlogin()

# Configure Django settings PARA USAR A MESMA CRIPTOGRAFIA
if not settings.configured:
    settings.configure(
        SECRET_KEY='django-insecure-sua-chave-secreta-aqui',  # USE A MESMA DO SEU DJANGO
        USE_TZ=True,
    )
    django.setup()

from django.contrib.auth.hashers import make_password, check_password

# Carrega os arquivos KV
Builder.load_file('cadastro.kv')

class CadastroScreen(Screen):
    def fazer_cadastro(self):
        """Realiza o cadastro do usuário com validações"""
        # Obtém os valores dos campos através dos IDs
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()
        nome = self.ids.nome_input.text.strip()
        sobrenome = self.ids.sobrenome_input.text.strip()
        
        # Determina o tipo de usuário baseado no botão selecionado
        if self.ids.cliente_btn.state == 'down':
            tipo_usuario = 'cliente'
        elif self.ids.barbearia_btn.state == 'down':
            tipo_usuario = 'barbearia'
        else:
            # Nenhum botão selecionado
            self.ids.mensagem_erro.text = "Selecione o tipo de usuário (Cliente ou Barbearia)"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Validação de campos vazios
        if not all([email, senha, nome, sobrenome]):
            self.ids.mensagem_erro.text = "Preencha todos os campos"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Validação de email
        if not self.validar_email(email):
            self.ids.mensagem_erro.text = "Email deve terminar com @gmail.com"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Validação de senha
        if not self.validar_senha(senha):
            self.ids.mensagem_erro.text = "Senha deve ter pelo menos 4 caracteres"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Verifica se email já existe
        if self.email_existe(email):
            self.ids.mensagem_erro.text = "Este email já está cadastrado"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Tenta fazer o cadastro
        if self.cadastrar_usuario(email, senha, nome, sobrenome, tipo_usuario):
            self.ids.mensagem_erro.text = "Cadastro realizado com sucesso!"
            self.ids.mensagem_erro.color = get_color_from_hex('#00AA00')
            
            # Armazena os dados do usuário no app
            app = App.get_running_app()
            app.email_usuario = email
            app.nome_usuario = f"{nome} {sobrenome}"
            
            # Limpa os campos após cadastro bem-sucedido
            self.ids.email_input.text = ""
            self.ids.senha_input.text = ""
            self.ids.nome_input.text = ""
            self.ids.sobrenome_input.text = ""
            
            # Redireciona para o login após 2 segundos
            Clock.schedule_once(lambda dt: self.ir_para_login(), 2)
            
            return True
        else:
            self.ids.mensagem_erro.text = "Erro ao cadastrar usuário"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
    
    def validar_email(self, email):
        """Valida se o email termina com @gmail.com"""
        return email.endswith('@gmail.com')
    
    def validar_senha(self, senha):
        """Valida se a senha tem pelo menos 4 caracteres"""
        return len(senha) >= 4
    
    def email_existe(self, email):
        """Verifica se o email já existe no banco"""
        conn = self.conectar_banco()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT id FROM regua2_usuario WHERE email = ?", (email,))
                return cursor.fetchone() is not None
            except sqlite3.Error as e:
                print(f"Erro ao verificar email: {e}")
                return False
            finally:
                conn.close()
        return False
    
    def cadastrar_usuario(self, email, senha, nome, sobrenome, tipo_usuario):
        """Cadastra o usuário no banco de dados COM CRIPTOGRAFIA DJANGO"""
        conn = self.conectar_banco()
        if conn:
            try:
                cursor = conn.cursor()
                
                # USA A CRIPTOGRAFIA DO DJANGO (PBKDF2)
                senha_criptografada = make_password(senha)
                
                # Insere o usuário no banco
                cursor.execute("""
                    INSERT INTO regua2_usuario 
                    (email, senha, nome, sobrenome, tipo) 
                    VALUES (?, ?, ?, ?, ?)
                """, (email, senha_criptografada, nome, sobrenome, tipo_usuario))
                
                conn.commit()
                return True
                
            except sqlite3.Error as e:
                print(f"Erro ao cadastrar usuário: {e}")
                return False
            finally:
                conn.close()
        return False
    
    def conectar_banco(self):
        """Conecta ao banco de dados SQLite"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            return conn
        except sqlite3.Error as e:
            print(f"Erro ao conectar ao banco: {e}")
            return None
    
    def ir_para_login(self):
        """Navega para a tela de login"""
        self.manager.current = 'login'
        # Limpa a mensagem ao mudar de tela
        self.ids.mensagem_erro.text = ""

# Importar as telas corretamente
from home import HomeScreen
from login import LoginScreen
from home_barbeiro import HomeScreenBarbeiro  
from perfil import ProfileScreen
from cadastro_barbearia import CadastroBarbeariaScreen
from minha_barbearia import MinhaBarbeariaScreen
from barbearias import BarbeariasScreen

class BarbeariaApp(App):
    usuario_id = None
    logado = False
    foto_perfil = ''
    email_usuario = ''
    nome_usuario = ''
    
    def build(self):
        # Cria o gerenciador de telas
        sm = ScreenManager()
        
        # Adiciona as telas CORRETAMENTE
        sm.add_widget(CadastroScreen(name='cadastro'))
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(HomeScreenBarbeiro(name='home_barbeiro'))
        sm.add_widget(ProfileScreen(name='perfil'))
        sm.add_widget(CadastroBarbeariaScreen(name='cadastro_barbearia'))
        sm.add_widget(MinhaBarbeariaScreen(name='editar_barbearia'))
        sm.add_widget(BarbeariasScreen(name='barbearias'))
        # Define a tela inicial como cadastro
        
        sm.current = 'cadastro'
        
        return sm

if __name__ == "__main__":
    BarbeariaApp().run()