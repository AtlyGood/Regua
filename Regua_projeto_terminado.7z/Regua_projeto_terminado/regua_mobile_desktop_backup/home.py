from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, Ellipse
from kivy.uix.behaviors import ButtonBehavior
from kivy.clock import Clock
from kivy.properties import StringProperty, BooleanProperty, NumericProperty, ListProperty
from kivy.metrics import dp, sp
from kivy.uix.widget import Widget
from kivy.core.image import Image as CoreImage
from io import BytesIO
import sqlite3
import os
import requests

class ProfileImage(ButtonBehavior, Image):
    """Widget personalizado para exibir imagem de perfil com formato circular"""
    def __init__(self, **kwargs):
        super(ProfileImage, self).__init__(**kwargs)
        self.allow_stretch = True
        self.keep_ratio = False
        
    def on_size(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(0.8, 0.8, 0.8, 1)
            Ellipse(pos=self.pos, size=self.size)

class CustomDropDown(DropDown):
    pass

class MenuButton(Button):
    pass

class HomeScreen(Screen):
    profile_photo = StringProperty('')
    is_mobile = BooleanProperty(False)
    background_image = StringProperty('')
    
    def __init__(self, **kwargs):
        super(HomeScreen, self).__init__(**kwargs)
        self.dropdown = CustomDropDown()
        Window.bind(on_resize=self.on_window_resize)
        
        Clock.schedule_once(self.init_ui, 0.1)
    
    
    def _update_bg(self, *args):
        """Atualiza o fundo mantendo a proporção da imagem"""
        if hasattr(self, 'bg_rect') and self.bg_rect.texture:
            # Obtém as dimensões da textura
            tex = self.bg_rect.texture
            if hasattr(tex, 'size'):
                img_width, img_height = tex.size
            else:
                # Se não tiver size attribute, usa valores padrão
                img_width, img_height = 100, 100
                
            img_ratio = img_width / img_height
            screen_ratio = self.width / self.height
            
            # Calcula o tamanho e posição para manter a proporção
            if screen_ratio > img_ratio:
                # Tela mais larga que a imagem - ajusta pela altura
                new_height = self.height
                new_width = new_height * img_ratio
                pos_x = (self.width - new_width) / 2
                pos_y = 0
            else:
                # Tela mais alta que a imagem - ajusta pela largura
                new_width = self.width
                new_height = new_width / img_ratio
                pos_x = 0
                pos_y = (self.height - new_height) / 2
            
            # Atualiza a posição e tamanho do retângulo
            self.bg_rect.pos = (self.x + pos_x, self.y + pos_y)
            self.bg_rect.size = (new_width, new_height)
        
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_foto_perfil()
        
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                conn = sqlite3.connect(r"C:\Users\Anthony54245016\Desktop\Regua_projeto_terminado\projeto_web\regua\db.sqlite3")
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        foto_path = os.path.join(r"C:\Users\Anthony54245016\Desktop\Regua_projeto_terminado\projeto_web\regua\perfil", filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids') and 'profile_image' in self.ids:
                            self.ids.profile_image.source = foto_path
                    else:
                        self.definir_imagem_padrao()
                else:
                    self.definir_imagem_padrao()
                    
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
                self.definir_imagem_padrao()
        else:
            self.definir_imagem_padrao()
    
    def definir_imagem_padrao(self):
        """Define uma imagem padrão quando não há foto"""
        self.profile_photo = ''
        
    def init_ui(self, dt):
        self.check_screen_size()
        
    def on_window_resize(self, window, width, height):
        self.check_screen_size()
        
    def check_screen_size(self):
        self.is_mobile = Window.width < dp(768)
        
    def create_dropdown(self):
        self.dropdown.clear_widgets()
        
        options = [
            ('Barbearias', self.go_to_barbearias),
            ('Agendamentos', self.go_to_agendamentos),
            ('Sair', self.logout)
        ]
        
        for text, callback in options:
            btn = MenuButton(
                text=text, 
                size_hint_y=None, 
                height=dp(50),
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1]
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def go_to_barbearias(self, instance):
        print("Navegar para barbearias")
        self.dropdown.dismiss()
    
    def go_to_agendamentos(self, instance):
        print("Navegar para agendamentos")
        self.dropdown.dismiss()
    
    def logout(self, instance):
        """Realiza logout do usuário"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id'):
            app.usuario_id = None
            app.logado = False
            app.foto_perfil = None
        
        self.manager.current = 'login'
        self.dropdown.dismiss()
    
    def open_dropdown(self, button):
        self.create_dropdown()
        self.dropdown.open(button)
    
    def go_to_perfil(self):
        print("Navegar para perfil")