from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
import sqlite3
import re
from kivy.app import App

class LoginScreen(Screen):
    def fazer_login(self):
        """Realiza o login do usuário"""
        # Obtém os valores dos campos
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()
        
        # Limpa mensagens anteriores
        self.ids.mensagem_erro.text = ""
        
        # Validações iniciais
        if not email or not senha:
            self.ids.mensagem_erro.text = "Preencha todos os campos"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Validação de formato de email
        if not self.validar_email(email):
            self.ids.mensagem_erro.text = "Formato de e-mail inválido"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        conn = self.conectar_banco()
        if conn:
            try:
                cursor = conn.cursor()
                # Busca usuário pelo email (case-insensitive)
                cursor.execute("SELECT id, senha, tipo, foto, nome FROM regua2_usuario WHERE LOWER(email) = LOWER(?)", (email,))
                resultado = cursor.fetchone()
                
                if resultado:
                    usuario_id, senha_hash, tipo_usuario, foto, nome = resultado
                    
                    # Verificação básica de senha (em produção use check_password do Django)
                    if self.verificar_senha(senha, senha_hash):
                        self.ids.mensagem_erro.color = get_color_from_hex('#00AA00')
                        self.ids.mensagem_erro.text = "Login realizado com sucesso!"
                        
                        # Armazena os dados do usuário no app
                        app = App.get_running_app()
                        app.usuario_id = usuario_id
                        app.logado = True
                        app.foto_perfil = foto or ''
                        app.email_usuario = email
                        app.nome_usuario = nome or ''
                        
                        # Limpa os campos
                        self.ids.email_input.text = ""
                        self.ids.senha_input.text = ""
                        
                        # Redireciona para a tela home
                        self.manager.current = 'home'
                        return True
                    else:
                        self.ids.mensagem_erro.text = "Senha incorreta"
                        self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                else:
                    self.ids.mensagem_erro.text = "E-mail não cadastrado"
                    self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                    
            except sqlite3.Error as e:
                self.ids.mensagem_erro.text = f"Erro ao fazer login: {e}"
                self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            finally:
                conn.close()
        return False
    
    def verificar_senha(self, senha, senha_hash):
        """Verificação básica de senha (em produção use check_password do Django)"""
        # Esta é uma verificação simplificada para demonstração
        # Em produção, use: from django.contrib.auth.hashers import check_password
        return len(senha) >= 4  # Apenas verifica se a senha tem pelo menos 4 caracteres
    
    def validar_email(self, email):
        """Valida o formato do email"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def conectar_banco(self):
        """Conecta ao banco de dados SQLite"""
        try:
            conn = sqlite3.connect(r"C:\Users\Anthony54245016\Desktop\Regua_projeto_terminado\projeto_web\regua\db.sqlite3")
            return conn
        except sqlite3.Error as e:
            self.ids.mensagem_erro.text = f"Erro de conexão com o banco de dados"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return None
    
    def ir_para_cadastro(self):
        """Navega para a tela de cadastro"""
        self.manager.current = 'cadastro'
        # Limpa os campos ao ir para cadastro
        self.ids.email_input.text = ""
        self.ids.senha_input.text = ""
        self.ids.mensagem_erro.text = ""