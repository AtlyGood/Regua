from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.dropdown import DropDown
from kivy.uix.modalview import ModalView
from kivy.properties import StringProperty, BooleanProperty, ListProperty, NumericProperty, ObjectProperty
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.clock import Clock
import sqlite3
import os
import requests
from kivy.lang import Builder
from datetime import datetime, timedelta
import json

usuario = os.getlogin()
Builder.load_file('agendamento_barb.kv')

class CustomDropDown(DropDown):
    pass

class MenuButton(Button):
    pass

class AgendamentoBarbCard(BoxLayout):
    agendamento_id = StringProperty('')
    cliente_nome = StringProperty('')
    cliente_telefone = StringProperty('')
    cliente_email = StringProperty('')
    data_agendamento = StringProperty('')
    horario_agendamento = StringProperty('')
    status = StringProperty('pendente')
    posicao = NumericProperty(0)
    foto_perfil = StringProperty('')
    
    def __init__(self, **kwargs):
        super(AgendamentoBarbCard, self).__init__(**kwargs)
        Clock.schedule_once(self.finalizar_inicializacao)
    
    def finalizar_inicializacao(self, dt):
        self.atualizar_interface()
    
    def atualizar_interface(self, *args):
        if hasattr(self, 'ids'):
            # Atualiza cores baseadas no status
            if self.status == 'cancelado':
                self.ids.status_label.color = (0.894, 0.102, 0.110, 1)  # Vermelho
                self.ids.confirmar_btn.opacity = 0
                self.ids.confirmar_btn.disabled = True
                self.ids.cancelar_btn.opacity = 0
                self.ids.cancelar_btn.disabled = True
            elif self.status == 'confirmado':
                self.ids.status_label.color = (0.156, 0.545, 0.270, 1)  # Verde
                self.ids.confirmar_btn.opacity = 0
                self.ids.confirmar_btn.disabled = True
                self.ids.cancelar_btn.opacity = 1
                self.ids.cancelar_btn.disabled = False
            else:  # pendente
                self.ids.status_label.color = (0.854, 0.647, 0.125, 1)  # Amarelo
                self.ids.confirmar_btn.opacity = 1
                self.ids.confirmar_btn.disabled = False
                self.ids.cancelar_btn.opacity = 1
                self.ids.cancelar_btn.disabled = False
            
            # Atualiza posição (só mostra para pendentes)
            if self.status == 'pendente':
                self.ids.posicao_label.text = f'{self.posicao}º'
                self.ids.posicao_label.color = (0.133, 0.773, 0.369, 1)
            else:
                self.ids.posicao_label.text = '-'
                self.ids.posicao_label.color = (0.5, 0.5, 0.5, 1)

class ConfirmacaoModal(ModalView):
    message = StringProperty('')
    callback = ObjectProperty(None)
    
    def __init__(self, message, callback, **kwargs):
        super(ConfirmacaoModal, self).__init__(**kwargs)
        self.message = message
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False

class CancelamentoModal(ModalView):
    message = StringProperty('')
    callback = ObjectProperty(None)
    
    def __init__(self, message, callback, **kwargs):
        super(CancelamentoModal, self).__init__(**kwargs)
        self.message = message
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False

class AgendamentoBarbScreen(Screen):
    agendamentos_data = ListProperty([])
    profile_photo = StringProperty('')
    is_mobile = BooleanProperty(False)
    filtro_data = StringProperty('')
    filtro_status = StringProperty('all')
    
    def __init__(self, **kwargs):
        super(AgendamentoBarbScreen, self).__init__(**kwargs)
        self.modal = None
        self.dropdown = CustomDropDown()
        # Verificar tamanho da tela ao inicializar
        from kivy.core.window import Window
        Window.bind(on_resize=self.on_window_resize)
        self.check_screen_size()
    
    def on_window_resize(self, window, width, height):
        """Atualiza responsividade quando a janela é redimensionada"""
        self.check_screen_size()
    
    def check_screen_size(self):
        """Verifica se está em modo mobile baseado na largura da tela"""
        from kivy.core.window import Window
        from kivy.metrics import dp
        self.is_mobile = Window.width < dp(768)
        
        # Atualizar o app global também
        app = App.get_running_app()
        if hasattr(app, 'is_mobile'):
            app.is_mobile = self.is_mobile
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_agendamentos()
        self.carregar_foto_perfil()
        self.create_dropdown()
    
    def create_dropdown(self):
        """Cria o menu dropdown"""
        self.dropdown.clear_widgets()
        
        options = [
            ('Cadastrar Barbearia', self.go_to_cadastrar_barbearia),
            ('Agendamentos', self.go_to_agendamentos),
            ('Minha Barbearia', self.go_to_minha_barbearia),
            ('Sair', self.logout)
        ]
        
        for text, callback in options:
            btn = MenuButton(
                text=text, 
                size_hint_y=None, 
                height=dp(50),
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1]
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def open_dropdown(self, button):
        """Abre o menu dropdown"""
        self.create_dropdown()
        self.dropdown.open(button)
    
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                        foto_path = os.path.join(base_path, filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids') and 'profile_image' in self.ids:
                            self.ids.profile_image.source = foto_path
                
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
    
    def carregar_agendamentos(self):
        """Carrega os agendamentos da barbearia do usuário logado"""
        app = App.get_running_app()
        if not hasattr(app, 'usuario_id') or not app.usuario_id:
            return
        
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # Busca a barbearia do usuário
            cursor.execute("SELECT id FROM regua2_barbearia WHERE usuario_id = ?", (app.usuario_id,))
            barbearia = cursor.fetchone()
            
            if not barbearia:
                print("Usuário não possui barbearia cadastrada")
                conn.close()
                return
            
            barbearia_id = barbearia[0]
            
            # Busca agendamentos da barbearia
            cursor.execute("""
                SELECT a.id, a.cliente_id, a.data, a.horario, a.confirmado, a.realizado,
                    u.nome, u.sobrenome, u.telefone, u.email, u.foto_perfil
                FROM regua2_agendamento a
                JOIN regua2_usuario u ON a.cliente_id = u.id
                WHERE a.barbearia_id = ?
                ORDER BY a.data, a.horario
            """, (barbearia_id,))
            
            agendamentos = cursor.fetchall()
            self.agendamentos_data = []
            
            for agendamento in agendamentos:
                (agendamento_id, cliente_id, data_agendamento, horario_agendamento, 
                 confirmado, realizado, nome, sobrenome, telefone, email, foto_perfil) = agendamento
                
                # Determina status
                if realizado:
                    status = 'concluido'
                elif confirmado:
                    status = 'confirmado'
                else:
                    status = 'pendente'
                
                agendamento_dict = {
                    'id': str(agendamento_id),
                    'cliente_id': str(cliente_id),
                    'cliente_nome': f"{nome} {sobrenome}",
                    'cliente_telefone': telefone or 'Telefone não informado',
                    'cliente_email': email or 'E-mail não informado',
                    'data_agendamento': data_agendamento,
                    'horario_agendamento': horario_agendamento,
                    'status': status,
                    'foto_perfil': foto_perfil or '',
                    'timestamp': self.criar_timestamp(data_agendamento, horario_agendamento)
                }
                self.agendamentos_data.append(agendamento_dict)
            
            conn.close()
            self.organizar_agendamentos()
            
        except Exception as e:
            print(f"Erro ao carregar agendamentos: {e}")
    
    def criar_timestamp(self, data_str, horario_str):
        """Cria timestamp para ordenação"""
        try:
            data_obj = datetime.strptime(data_str, '%Y-%m-%d')
            horario_obj = datetime.strptime(horario_str, '%H:%M:%S').time()
            return datetime.combine(data_obj, horario_obj).timestamp()
        except:
            return 0
    
    def organizar_agendamentos(self):
        """Organiza os agendamentos por status e horário (igual ao HTML)"""
        # Define a ordem de prioridade: pendente > confirmado > concluido
        status_order = {'pendente': 1, 'confirmado': 2, 'concluido': 3}
        
        # Ordena os agendamentos
        self.agendamentos_data.sort(key=lambda x: (
            status_order.get(x['status'], 4),  # Primeiro por status
            x['timestamp']  # Depois por timestamp (mais antigo primeiro)
        ))
        
        # Atualiza as posições apenas para agendamentos pendentes
        posicao = 1
        for agendamento in self.agendamentos_data:
            if agendamento['status'] == 'pendente':
                agendamento['posicao'] = posicao
                posicao += 1
            else:
                agendamento['posicao'] = 0
        
        self.aplicar_filtros()
    
    def aplicar_filtros(self):
        """Aplica os filtros de data e status"""
        agendamentos_filtrados = []
        
        for agendamento in self.agendamentos_data:
            # Filtro por data
            if self.filtro_data:
                data_formatada = self.formatar_data_para_filtro(agendamento['data_agendamento'])
                if data_formatada != self.filtro_data:
                    continue
            
            # Filtro por status
            if self.filtro_status != 'all' and agendamento['status'] != self.filtro_status:
                continue
            
            agendamentos_filtrados.append(agendamento)
        
        self.atualizar_interface(agendamentos_filtrados)
    
    def formatar_data_para_filtro(self, data_str):
        """Formata data para comparação com o filtro"""
        try:
            data_obj = datetime.strptime(data_str, '%Y-%m-%d')
            return data_obj.strftime('%d/%m/%Y')
        except:
            return data_str
    
    def atualizar_interface(self, agendamentos=None):
        """Atualiza a interface com os agendamentos carregados"""
        if agendamentos is None:
            agendamentos = self.agendamentos_data
        
        if hasattr(self, 'ids') and 'agendamentos_container' in self.ids:
            self.ids.agendamentos_container.clear_widgets()
            
            if not agendamentos:
                # Quando não há agendamentos
                empty_label = Label(
                    text="Nenhum agendamento encontrado",
                    size_hint_y=None,
                    height=dp(100),
                    color=(0.5, 0.5, 0.5, 1),
                    font_size=dp(16)
                )
                self.ids.agendamentos_container.add_widget(empty_label)
                return
            
            for agendamento in agendamentos:
                card = AgendamentoBarbCard(
                    agendamento_id=agendamento['id'],
                    cliente_nome=agendamento['cliente_nome'],
                    cliente_telefone=agendamento['cliente_telefone'],
                    cliente_email=agendamento['cliente_email'],
                    data_agendamento=self.formatar_data(agendamento['data_agendamento']),
                    horario_agendamento=self.formatar_horario(agendamento['horario_agendamento']),
                    status=agendamento['status'],
                    posicao=agendamento['posicao'],
                    foto_perfil=self.obter_caminho_foto(agendamento['foto_perfil'])
                )
                # Bind dos botões
                card.ids.confirmar_btn.bind(
                    on_release=lambda instance, aid=agendamento['id']: self.confirmar_agendamento(aid)
                )
                card.ids.cancelar_btn.bind(
                    on_release=lambda instance, aid=agendamento['id']: self.cancelar_agendamento(aid)
                )
                self.ids.agendamentos_container.add_widget(card)
    
    def obter_caminho_foto(self, foto_path):
        """Obtém o caminho absoluto da foto"""
        if not foto_path:
            return ''
        
        try:
            if not os.path.isabs(foto_path):
                if foto_path.startswith('perfil/'):
                    filename = foto_path.replace('perfil/', '')
                else:
                    filename = foto_path
                
                base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                foto_path_abs = os.path.join(base_path, filename)
                
                if os.path.exists(foto_path_abs):
                    return foto_path_abs
            
            return foto_path
        except:
            return ''
    
    def formatar_data(self, data_str):
        """Formata a data para exibição"""
        try:
            data_obj = datetime.strptime(data_str, '%Y-%m-%d')
            return data_obj.strftime('%d/%m/%Y')
        except:
            return data_str
    
    def formatar_horario(self, horario_str):
        """Formata o horário para exibição"""
        try:
            horario_obj = datetime.strptime(horario_str, '%H:%M:%S')
            return horario_obj.strftime('%H:%M')
        except:
            return horario_str
    
    def confirmar_agendamento(self, agendamento_id):
        """Confirma um agendamento"""
        def confirmar(instance):
            if self.executar_confirmacao(agendamento_id):
                self.modal.dismiss()
                self.carregar_agendamentos()  # Recarrega a lista
        
        self.modal = ConfirmacaoModal(
            message="Deseja confirmar este agendamento?",
            callback=confirmar
        )
        self.modal.open()
    
    def cancelar_agendamento(self, agendamento_id):
        """Cancela um agendamento"""
        def confirmar_cancelamento(instance):
            if self.executar_cancelamento(agendamento_id):
                self.modal.dismiss()
                self.carregar_agendamentos()  # Recarrega a lista
        
        self.modal = CancelamentoModal(
            message="Tem certeza que deseja cancelar este agendamento?",
            callback=confirmar_cancelamento
        )
        self.modal.open()
    
    def executar_confirmacao(self, agendamento_id):
        """Executa a confirmação no banco de dados"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            cursor.execute("UPDATE regua2_agendamento SET confirmado = 1 WHERE id = ?", (agendamento_id,))
            conn.commit()
            conn.close()
            return True
                
        except Exception as e:
            print(f"Erro ao confirmar agendamento: {e}")
            return False
    
    def executar_cancelamento(self, agendamento_id):
        """Executa o cancelamento no banco de dados"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            cursor.execute("DELETE FROM regua2_agendamento WHERE id = ?", (agendamento_id,))
            conn.commit()
            conn.close()
            return True
                
        except Exception as e:
            print(f"Erro ao cancelar agendamento: {e}")
            return False
    
    def mostrar_notificacao(self, mensagem, tipo="success"):
        """Mostra uma notificação"""
        # Implementar notificação estilo toast se necessário
        print(f"{tipo.upper()}: {mensagem}")
    
    def on_filtro_data(self, instance, value):
        """Quando o filtro de data muda"""
        if hasattr(self, 'agendamentos_data'):
            self.aplicar_filtros()
    
    def on_filtro_status(self, instance, value):
        """Quando o filtro de status muda"""
        if hasattr(self, 'agendamentos_data'):
            self.aplicar_filtros()
    
    def voltar_home(self):
        """Volta para a tela home do barbeiro"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'home_barbeiro'
    
    def ir_para_perfil(self):
        """Navega para o perfil"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'perfil'
    
    # Funções de navegação do dropdown
    def go_to_cadastrar_barbearia(self, instance):
        self.dropdown.dismiss()
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'cadastro_barbearia'
    
    def go_to_agendamentos(self, instance):
        self.dropdown.dismiss()
        # Já está na tela de agendamentos
    
    def go_to_minha_barbearia(self, instance):
        self.dropdown.dismiss()
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'editar_barbearia'
    
    def logout(self, instance):
        """Realiza logout"""
        app = App.get_running_app()
        app.usuario_id = None
        app.logado = False
        app.foto_perfil = None
        app.tipo_usuario = None
        self.dropdown.dismiss()
        self.manager.current = 'login'